package com.example.inventory_svc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventorySvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
